// Akan Muncul di Console
console.log("Hello Dunia!");
